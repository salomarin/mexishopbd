package org.mexishop.mexishop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MexishopApplication {

	public static void main(String[] args) {
		SpringApplication.run(MexishopApplication.class, args);
	}

}
